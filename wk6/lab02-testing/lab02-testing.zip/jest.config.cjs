module.exports = {
    testEnvironment: "node",
    transform: {},
    verbose: true,
};
